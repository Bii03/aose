par-planner
===========

Goal stack planner for the PAR subject of the Master in Artificial Intelligence

The content of src contains the hierarchy of packets of the Java project, in this case, a single packet named blocksworld
